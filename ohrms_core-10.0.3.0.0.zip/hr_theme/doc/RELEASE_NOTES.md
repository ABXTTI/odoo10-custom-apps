## Module hr_theme

#### 07.04.2018
#### Version 10.0.1.1.0
##### CHG
- style issue in external link button fixed.
- style issue in mandatory field fixed.

#### 30.03.2018
#### Version 10.0.1.0.0
##### ADD
- Initial commit for OpenHrms Project
