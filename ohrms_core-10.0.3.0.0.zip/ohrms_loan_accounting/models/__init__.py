# -*- coding: utf-8 -*-
import hr_loan_config
import hr_loan_acc

