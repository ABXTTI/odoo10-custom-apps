## Module <ohrms_loan_accounting>

#### 09.04.2018
#### Version 10.0.2.0.0
##### CHG
- function changed.

#### 30.03.2018
#### Version 10.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project
