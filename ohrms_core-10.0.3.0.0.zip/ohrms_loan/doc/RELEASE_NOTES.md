## Module <ohrms_loan>

#### 09.04.2018
#### Version 10.0.2.0.0
##### CHG
- file name changed.
- fields removed.

#### 30.03.2018
#### Version 10.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project
