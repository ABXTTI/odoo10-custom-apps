<div align="center">
    <h3>Odoo Community version 10.0</h3>
    <p>Custom modules I made for Odoo</p>
    <p><a href="https://ko-fi.com/P5P4FOM0" target="_blank"><img src="https://www.ko-fi.com/img/donate_sm.png" alt="ko-fi"/></a></p>
    <p>if you want to support me to keep this project maintained. Thanks :)</p>
</div>
