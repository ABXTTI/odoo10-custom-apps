Web Wizard Dialog Resize
========================

Add an options to resize the window of wizard dialog.
