# -*- coding: utf-8 -*-
# License AGPL-3
import models
from hooks import uninstall_hook