# -*- coding: utf-8 -*-
import ir_ui_view
import ir_actions_act_window
import ir_actions_act_window_view
import res_partner
import res_config
