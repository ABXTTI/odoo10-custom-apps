Car Workshop v10
================
Car Workshop Management helps to manage automobile workshop with
great ease. Keep track of everything, like vehicle owner details,
Works assigned, Bill details of service provided, etc.

Features
========
* User Friendly Interface.
* Effective Time management.
* Separate Journal Configuration.
* Integrated with Accounting.
* High Scalability.

  .. note::

      # Its Working Domain Based on Project App.
      # Mapped Fleet for Easy Method.
